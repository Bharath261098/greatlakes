# Python-Webapp
Tutorial on making a Webapp using Python, Flask, and mySQL. Tutorial at https://code.tutsplus.com/tutorials/creating-a-web-app-from-scratch-using-python-flask-and-mysql--cms-22972 
